package Modelo;

public class BichinhoHorizontal extends Animado {

    private boolean bRight;
    int delayMovimento;

    public BichinhoHorizontal(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bRight = true;
        delayMovimento = 0;
    }

    public void autoDesenho() {
        delayMovimento++;

        // Só tenta mover quando atingir o delay máximo
        if(delayMovimento < 5) {
            super.autoDesenho();
            return;
        }

        delayMovimento = 0; // Reset do contador

        // Tenta mover na direção atual
        boolean movimentoRealizado = bRight ? moveRight() : moveLeft();

        // Se não conseguiu mover, inverte a direção e tenta novamente
        if(!movimentoRealizado) {
            bRight = !bRight; // Inverte a direção

            // Tenta mover na nova direção imediatamente
            if(bRight) {
                moveRight();
            } else {
                moveLeft();
            }
        }

        super.autoDesenho();
    }

}


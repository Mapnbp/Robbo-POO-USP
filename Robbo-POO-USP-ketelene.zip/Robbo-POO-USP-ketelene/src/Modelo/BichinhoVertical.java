package Modelo;

public class BichinhoVertical extends Animado {
    private boolean bUp;
    private int delayMovimento;
    private static final int DELAY_MAXIMO = 10; // Controla a velocidade

    public BichinhoVertical(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bUp = true;
        delayMovimento = 0;
    }
    public void autoDesenho() {
        delayMovimento++;

        // Só tenta mover quando atingir o delay máximo
        if(delayMovimento < DELAY_MAXIMO) {
            super.autoDesenho();
            return;
        }

        delayMovimento = 0; // Reset do contador

        // Tenta mover na direção atual
        boolean movimentoRealizado = bUp ? moveUp() : moveDown();

        // Se não conseguiu mover, inverte a direção
        if(!movimentoRealizado) {
            bUp = !bUp;
            // Tenta mover na nova direção imediatamente
            if(bUp) {
                moveUp();
            } else {
                moveDown();
            }
        }

        super.autoDesenho();
    }

}

package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;

public class Atirador extends Estatico {
    private int iContaIntervalos;
    
    public Atirador(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.iContaIntervalos = 0;
    }

    public void autoDesenho() {
        super.autoDesenho();

        this.iContaIntervalos++;
        if(this.iContaIntervalos == Consts.TIMER){
            this.iContaIntervalos = 1;
            Fogo f = new Fogo("fire.png");
            f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna()+1);
            Desenho.getTelaJogo().adicionarPersonagem(f);
        }
    }    
}

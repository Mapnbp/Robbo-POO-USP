package Modelo;

import Auxiliar.Desenho;

public class Ingrediente extends Estatico{
    public Ingrediente(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bTransponivel = true;
    }

}

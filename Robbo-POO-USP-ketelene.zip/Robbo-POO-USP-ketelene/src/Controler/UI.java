package Controler;

import Modelo.Hero;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class UI {

        Tela tela;
        Font arial;

        Graphics g;

        public UI(Tela tela){
            this.tela = tela;
            this.arial = tela.arial;
        }

        public void escreveInfos(Graphics g){
            this.g = g;

            Fase faseAtual = tela.getFaseAtual();
            Hero heroi = tela.getHero();

            g.setFont(arial);
            g.setColor(Color.black);

            String infoFase = "FASE " + faseAtual.getNroFase();
            g.drawString(infoFase, 60 ,30);

            int vidas = heroi.getVidas();
            String infoVida = "Vidas: " + vidas;
            g.drawString(infoVida , 250, 30);


            int N = faseAtual.getiTotalIngredientes();
            String infoIng = "";

            if(N !=1)
                infoIng = "Faltam " + N + " ingredientes";
            else
                infoIng = "Faltam " + N + " ingredientes";

            g.drawString(infoIng , 450 , 30);
        }

    }

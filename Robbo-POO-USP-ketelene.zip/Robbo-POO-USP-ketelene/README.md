# Robbo-POO-USP
Porjeto final dos gavioes
obs: NECESSARIO VERSÃO 11 DO JAVA 

Bullet Points para o projeto:
* Definir o mapa; 
    - as fases 5 fases não precisam ser em seguida;
    - em cada fase deve ter um personagem novo;
      
* Criar a classe 'fase' composta pelo conjunto de personagens que pertencem a fase, só passa a lista desses personagens e o mapa desenhado;
    - trocar de fase significa apenas substituir o objeto fase atual;

